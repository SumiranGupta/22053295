import React, { useEffect, useState } from "react";
import { getTopUsers } from "../services/dataProcessing";
import { List, ListItem, ListItemText, Typography } from "@mui/material";

const TopUsers = () => {
  const [topUsers, setTopUsers] = useState([]);

  useEffect(() => {
    const fetchTopUsers = async () => {
      const users = await getTopUsers();
      setTopUsers(users);
    };
    fetchTopUsers();
  }, []);

  return (
    <div>
      <Typography variant="h6">Top Users</Typography>
      <List>
        {topUsers.map((user) => (
          <ListItem key={user.userId}>
            <ListItemText primary={`${user.name} - ${user.postCount} posts`} />
          </ListItem>
        ))}
      </List>
    </div>
  );
};

export default TopUsers;
