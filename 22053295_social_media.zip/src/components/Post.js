import React from "react";
import { Card, CardContent, Typography } from "@mui/material";

const Post = ({ post }) => {
  return (
    <Card style={{ marginBottom: "16px" }}>
      <CardContent>
        <Typography variant="subtitle1">{post.author}</Typography>
        <Typography variant="body1">{post.content}</Typography>
      </CardContent>
    </Card>
  );
};

export default Post;
