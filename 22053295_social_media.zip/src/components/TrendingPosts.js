import React, { useEffect, useState } from "react";
import { getTrendingPosts } from "../services/dataProcessing";
import { List, ListItem, ListItemText, Typography } from "@mui/material";

const TrendingPosts = () => {
  const [trendingPosts, setTrendingPosts] = useState([]);

  useEffect(() => {
    const fetchTrendingPosts = async () => {
      const posts = await getTrendingPosts();
      setTrendingPosts(posts);
    };
    fetchTrendingPosts();
  }, []);

  return (
    <div>
      <Typography variant="h6">Trending Posts</Typography>
      <List>
        {trendingPosts.map((post) => (
          <ListItem key={post.id}>
            <ListItemText
              primary={post.content}
              secondary={`Comments: ${post.commentCount}`}
            />
          </ListItem>
        ))}
      </List>
    </div>
  );
};

export default TrendingPosts;
