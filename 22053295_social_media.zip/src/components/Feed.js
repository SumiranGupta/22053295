import React, { useEffect, useState } from "react";
import { fetchUsers, fetchPostsByUser } from "../services/api";
import Post from "./Post";
import { Typography } from "@mui/material";

const Feed = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchFeed = async () => {
      const users = await fetchUsers();
      const allPosts = await Promise.all(
        Object.keys(users).map(async (userId) => {
          const userPosts = await fetchPostsByUser(userId);
          return userPosts.map((post) => ({ ...post, author: users[userId] }));
        })
      );
      const sortedPosts = allPosts.flat().sort((a, b) => b.id - a.id);
      setPosts(sortedPosts);
    };
    fetchFeed();
  }, []);

  return (
    <div>
      <Typography variant="h6">Feed</Typography>
      {posts.map((post) => (
        <Post key={post.id} post={post} />
      ))}
    </div>
  );
};

export default Feed;
