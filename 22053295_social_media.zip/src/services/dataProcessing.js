import { fetchUsers, fetchPostsByUser, fetchCommentsByPost } from "./api";

export const getTopUsers = async () => {
  const users = await fetchUsers();
  const userPostCounts = await Promise.all(
    Object.keys(users).map(async (userId) => {
      const posts = await fetchPostsByUser(userId);
      return { userId, name: users[userId], postCount: posts.length };
    })
  );
  return userPostCounts.sort((a, b) => b.postCount - a.postCount).slice(0, 5);
};

export const getTrendingPosts = async () => {
  const users = await fetchUsers();
  const allPosts = await Promise.all(
    Object.keys(users).map(async (userId) => {
      const posts = await fetchPostsByUser(userId);
      return posts;
    })
  );
  const posts = allPosts.flat();
  const postCommentCounts = await Promise.all(
    posts.map(async (post) => {
      const comments = await fetchCommentsByPost(post.id);
      return { ...post, commentCount: comments.length };
    })
  );
  const maxComments = Math.max(...postCommentCounts.map((p) => p.commentCount));
  return postCommentCounts.filter((p) => p.commentCount === maxComments);
};
