import axios from "axios";

export const fetchUsers = async () => {
  const response = await axios.get("/evaluation-service/users");
  return response.data.users;
};

export const fetchPostsByUser = async (userId) => {
  const response = await axios.get(`/evaluation-service/users/${userId}/posts`);
  return response.data.posts;
};

export const fetchCommentsByPost = async (postId) => {
  const response = await axios.get(
    `/evaluation-service/posts/${postId}/comments`
  );
  return response.data.comments;
};
