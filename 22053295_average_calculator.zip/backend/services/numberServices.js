const axios = require("axios");

const API_BASE = "http://20.244.56.144/evaluation-service";

exports.fetchNumbers = async (type) => {
  try {
    const response = await axios.get(`${API_BASE}/${type}`, { timeout: 500 });
    return response.data;
  } catch (error) {
    console.error(`Error fetching ${type} numbers:`, error.message);
    return null;
  }
};
