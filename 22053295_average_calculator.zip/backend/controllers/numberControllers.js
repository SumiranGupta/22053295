const numberService = require("../services/numberService");
const { calculateAverage } = require("../utils/utils");

const WINDOW_SIZE = 10;
let numberWindow = [];

exports.getNumbers = async (req, res) => {
  const numberId = req.params.numberId;
  const validIds = ["p", "f", "e", "r"];
  const idMap = { p: "primes", f: "fibo", e: "even", r: "rand" };

  if (!validIds.includes(numberId)) {
    return res.status(400).json({ error: "Invalid number ID" });
  }

  const apiType = idMap[numberId];
  try {
    const response = await numberService.fetchNumbers(apiType);

    if (response) {
      const numbers = response.numbers;
      const windowPrevState = [...numberWindow];

      numbers.forEach((num) => {
        if (!numberWindow.includes(num)) {
          if (numberWindow.length >= WINDOW_SIZE) {
            numberWindow.shift(); // Remove oldest element
          }
          numberWindow.push(num); // Add new element
        }
      });

      const avg = calculateAverage(numberWindow);
      return res.json({
        windowPrevState,
        windowCurrState: numberWindow,
        numbers,
        avg: avg.toFixed(2),
      });
    }
  } catch (error) {
    return res.status(500).json({ error: "Error fetching numbers" });
  }
};
