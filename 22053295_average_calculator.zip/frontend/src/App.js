import React, { useState } from "react";
import AverageDisplay from "./components/AverageDisplay";
import axios from "axios";

function App() {
  const [numberType, setNumberType] = useState("e");
  const [responseData, setResponseData] = useState(null);

  const handleFetch = async () => {
    try {
      const response = await axios.post("http://localhost:9876/numbers", {
        numberType,
      });
      setResponseData(response.data);
    } catch (error) {
      console.error("Error fetching numbers:", error.message);
    }
  };

  return (
    <div className="min-h-screen p-8 bg-gray-100 flex flex-col items-center">
      <h1 className="text-2xl font-bold mb-4">
        Average Calculator Microservice
      </h1>
      <div className="mb-4">
        <select
          className="p-2 rounded border border-gray-300"
          value={numberType}
          onChange={(e) => setNumberType(e.target.value)}
        >
          <option value="p">Prime</option>
          <option value="f">Fibonacci</option>
          <option value="e">Even</option>
          <option value="r">Random</option>
        </select>
        <button
          onClick={handleFetch}
          className="ml-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Fetch Numbers
        </button>
      </div>
      {responseData && (
        <div>
          <h3>
            Previous State: {JSON.stringify(responseData.windowPrevState)}
          </h3>
          <h3>Current State: {JSON.stringify(responseData.windowCurrState)}</h3>
          <h3>Numbers: {JSON.stringify(responseData.numbers)}</h3>
          <h3>Average: {responseData.avg}</h3>
        </div>
      )}
    </div>
  );
}

export default App;
