import React from "react";

function AverageDisplay({ data }) {
  return (
    <div className="p-4 bg-white shadow rounded-md w-full max-w-xl">
      <h2 className="text-xl font-semibold mb-2">Average Calculation</h2>
      <p>
        <strong>Previous State:</strong> {JSON.stringify(data.windowPrevState)}
      </p>
      <p>
        <strong>Current State:</strong> {JSON.stringify(data.windowCurrState)}
      </p>
      <p>
        <strong>Received Numbers:</strong> {JSON.stringify(data.numbers)}
      </p>
      <p>
        <strong>Average:</strong> {data.avg}
      </p>
    </div>
  );
}

export default AverageDisplay;
