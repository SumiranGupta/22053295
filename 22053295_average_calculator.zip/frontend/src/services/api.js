export const fetchNumbers = async (numberType) => {
  try {
    const response = await fetch(`http://localhost:9876/numbers/${numberType}`);
    if (!response.ok) throw new Error("Failed to fetch numbers");
    return await response.json();
  } catch (error) {
    console.error("Error fetching numbers:", error);
    return null;
  }
};
